// SPORTLAB V7.0.0 — Legacy runtime encapsulated by Sprint 7.1 Core Foundation
import { loadApplicationData } from "./services/appService.js";

import { computeValue } from "./core/engines/valueEngine.js";

import {
  createBet,
  getAllBets
} from "./services/betService.js";

import {
  runAutomaticSettlement
} from "./services/settlementService.js";
import { evaluatePendingPredictions } from "./core/performance/predictionEvaluationEngine.js";

import { saveAnalysis, getAnalysisForMatch } from "./core/stores/analysisStore.js";

import { renderApplication } from "./services/renderService.js";

import { initSportLabUi } from "./ui/interactions/sportlabUi.js";
import { initDashboardPremium } from "./ui/interactions/dashboardPremium.js";
import { initDrawHunterWorkflow } from "./ui/interactions/drawHunterWorkflow.js";
import { initFrenchFlairWorkflow } from "./ui/interactions/frenchFlairWorkflow.js";
import { saveDrawHunterMatchWorkflow } from "./core/stores/drawHunterWorkflowStore.js";
import { saveFrenchFlairMatchWorkflow } from "./core/stores/frenchFlairWorkflowStore.js";

import {
  runSettlementDiagnostics
} from "./debug/settlementDiagnostics.js";

let drawhunterPayload = null;
let frenchflairPayload = null;
const pendingFrenchFlairAnalyses = new Map();
let currentPage = "home";

function isMatchEditableBeforeKickoff(match) {
  const kickoff = Date.parse(match?.date || match?.matchDate || "");
  return Number.isFinite(kickoff) && kickoff > Date.now();
}

function initializeUi() {
  initSportLabUi();
  initDashboardPremium();
  initDrawHunterWorkflow();
  initFrenchFlairWorkflow();
}

async function init() {
  const app = document.getElementById("app");

  try {
    app.innerHTML = `
      <h1>🏟️ SportLab</h1>
      <p>Chargement...</p>
    `;

    const appData = await loadApplicationData();

drawhunterPayload = appData.drawhunterPayload;
frenchflairPayload = appData.frenchflairPayload;

    renderApplication(app, {
      ...appData,
      currentPage
    });

    initializeUi();

    try {
      const predictionEvaluation = await evaluatePendingPredictions();
      console.log("[PredictionEvaluation]", predictionEvaluation);
      if (predictionEvaluation.evaluated > 0) {
        renderApplication(app, { ...appData, currentPage });
        initializeUi();
      }
    } catch (error) {
      console.warn("[PredictionEvaluation] Échec", error);
    }

    try {
      const settlement = await runAutomaticSettlement();

      console.log(
        "[Settlement] Règlement automatique terminé :",
        settlement.reports
      );

      const hasSettledBet = settlement.settledCount > 0;

      if (hasSettledBet) {
    const refreshedData =
        await loadApplicationData();

    drawhunterPayload =
        refreshedData.drawhunterPayload;

    frenchflairPayload =
        refreshedData.frenchflairPayload;

    renderApplication(app, {
      ...refreshedData,
      currentPage
    });

    initializeUi();
}
   } catch (error) {
      console.error(
        "[Settlement] Échec du règlement automatique :",
        error
      );
    }
  } catch (error) {
    console.error(
      "SportLab init error:",
      error
    );

    const message =
      error?.message ||
      String(error) ||
      "Erreur inconnue au chargement de SportLab.";

    app.innerHTML = `
      <h1>🏟️ SportLab</h1>

      <section class="card">
        <h2>Erreur de chargement</h2>
        <p>${message}</p>
      </section>
    `;
  }
}

/**
 * DRAWHUNTER
 */
window.saveDrawHunterBet = function(index) {
  const match = drawhunterPayload?.matches?.[index];

  if (!match) {
    alert("Match introuvable.");
    return;
  }

  if (!isMatchEditableBeforeKickoff(match)) {
    alert("Le match a commencé : l’analyse et le pari sont désormais en lecture seule.");
    return;
  }

  const bookmakerOdds = Number(
    document.getElementById(`draw-odds-${match.id}`)?.value || 0
  );
  const placed = document.getElementById(`draw-placed-${match.id}`)?.checked;
  const stake = Number(document.getElementById(`draw-stake-${match.id}`)?.value || 0);

  if (!Number.isFinite(bookmakerOdds) || bookmakerOdds <= 1) {
    alert("Saisis une cote bookmaker valide avant d’enregistrer.");
    return;
  }

  if (placed && stake <= 0) {
    alert("Saisis un montant misé valide.");
    return;
  }

  const valuation = computeValue({
    probability: match.probability,
    odds: bookmakerOdds,
    minValue: 0.01
  });

  const saved = createBet({
  source: "DrawHunter",
  sport: "football",
  competition: match.competition || null,

  matchId: match.id ?? null,
  matchDate: match.date || null,

  match: `${match.home} vs ${match.away}`,
  home: match.home,
  away: match.away,
  homeId: match.homeId ?? null,
  awayId: match.awayId ?? null,
  homeLogo: match.homeLogo || null,
  awayLogo: match.awayLogo || null,
  market: "DRAW",
  line: null,
  odds: bookmakerOdds,
  probability: match.probability,
  value: valuation.value,
  edge: valuation.edge,
  decision: valuation.decision,
  placed,
  stake
});

  saveDrawHunterMatchWorkflow(match.id, {
    status: "awaiting_result",
    bookmakerOdds,
    impliedProbability: valuation.impliedProbability,
    value: valuation.value,
    edge: valuation.edge,
    decision: valuation.decision,
    reason: valuation.reason,
    placed: Boolean(saved.placed),
    stake: Number(saved.stake || 0),
    event: {
      type: saved.placed ? "tracked" : "decided",
      label: saved.placed ? "Pari enregistré" : "Analyse enregistrée",
      note: saved.placed ? `Mise : ${Number(saved.stake || 0).toFixed(2)} €` : "Aucun pari placé"
    }
  });

  alert(saved.placed ? "Pari DrawHunter sauvegardé." : "Analyse DrawHunter sauvegardée.");
  init();
};

/**
 * FRENCHFLAIR — OUVERTURE FICHE MANUELLE
 */
window.analyzeFrenchFlairValue = function(matchId) {
  const match = getFrenchFlairMatchById(matchId);
  
  if (!match) {
    alert("Match introuvable.");
    return;
  }

  const existing = getAnalysisForMatch(match.id);
  const box = document.getElementById(`ff-result-${match.id}`);

  if (!box) return;

  box.innerHTML = `
    <hr/>

    <h3>Analyse FrenchFlair</h3>

    <label>
      Marché
      <select id="ff-market-${match.id}">
        <option value="OVER" ${existing?.market === "OVER" ? "selected" : ""}>Over</option>
        <option value="UNDER" ${existing?.market === "UNDER" ? "selected" : ""}>Under</option>
      </select>
    </label>

    <label>
      Ligne bookmaker
      <input id="ff-line-${match.id}" type="number" step="0.5" placeholder="Ex : 45.5" value="${existing?.line ?? ""}">
    </label>

    <label>
      Cote
      <input id="ff-odds-${match.id}" type="number" step="0.01" placeholder="Ex : 1.90" value="${existing?.odds || ""}">
    </label>

    <label>
      Notes
      <input id="ff-notes-${match.id}" type="text" placeholder="Observation personnelle" value="${existing?.notes ?? ""}">
    </label>

    <button onclick="calculateFrenchFlairAnalysis('${match.id}')">
      Calculer la value
    </button>

    <div id="ff-calculation-${match.id}" style="margin-top:12px;"></div>
  `;
};

/**
 * FRENCHFLAIR — CALCUL AUTOMATIQUE DE LA VALUE
 *
 * Le calcul ne sauvegarde rien immédiatement.
 * L’utilisateur peut modifier la ligne ou la cote,
 * puis sauvegarder volontairement l’analyse.
 */
window.calculateFrenchFlairAnalysis = function(matchId) {
  const match = getFrenchFlairMatchById(matchId);

  if (!match) {
    alert("Match introuvable.");
    return;
  }

  if (!isMatchEditableBeforeKickoff(match)) {
    alert("Le match a commencé : la ligne, la cote et la décision sont désormais en lecture seule.");
    return;
  }

  const market =
    document.getElementById(`ff-market-${match.id}`)?.value ||
    match.recommendedTrend ||
    "OVER";

  const line = Number(
    document.getElementById(`ff-line-${match.id}`)?.value || 0
  );

  const odds = Number(
    document.getElementById(`ff-odds-${match.id}`)?.value || 0
  );

  const notes =
    document.getElementById(`ff-notes-${match.id}`)?.value || "";

  if (!market || line <= 0 || odds <= 1) {
    alert("Saisis une ligne bookmaker et une cote valides.");
    return;
  }

  const predictedTotal = Number(match.predictedTotalPoints || 0);
  const sigma = Number(match.sigma || 0);
  const confidence = Number(match.confidence || 0);

  if (
    !Number.isFinite(predictedTotal) ||
    predictedTotal <= 0 ||
    !Number.isFinite(sigma) ||
    sigma <= 0
  ) {
    alert(
      "Calcul indisponible : le total prédit ou le sigma est manquant."
    );
    return;
  }

  /*
   * Probabilité automatiquement calculée à partir :
   * - du total prédit ;
   * - du sigma ;
   * - de la ligne bookmaker ;
   * - du marché Over ou Under.
   */
  const probability = computeFrenchFlairProbability(
    match,
    market,
    line
  );

  if (!Number.isFinite(probability) || probability <= 0) {
    alert("La probabilité automatique n’a pas pu être calculée.");
    return;
  }

  const probabilityPercent = probability * 100;

  /*
   * Value mathématique :
   * probabilité SportLab comparée à la probabilité implicite de la cote.
   */
  const value = computeValue({
    probability,
    odds,
    minValue: 0.01
  });

  /*
   * Écart entre la prédiction SportLab et la ligne bookmaker.
   * Un écart positif va dans le sens du marché sélectionné.
   */
  const modelEdgePoints =
    market === "OVER"
      ? predictedTotal - line
      : line - predictedTotal;

  const modelEdgePercent =
    line > 0
      ? (modelEdgePoints / line) * 100
      : 0;

  /*
   * Score Value SportLab :
   * - écart modèle/bookmaker : 40 %
   * - confiance : 20 %
   * - sigma : 20 %
   * - value mathématique : 20 %
   */
  const scoreValue = computeFrenchFlairScore({
    modelEdgePercent,
    confidence,
    sigma,
    predictedTotal,
    mathValue: value.value
  });

  const finalDecision =
    scoreValue >= 70
      ? "VALUE"
      : "NO VALUE";

  /*
   * Brouillon temporaire.
   * Rien n’est encore enregistré dans analysisStore.
   */
  const analysis = {
    source: "FrenchFlair",
    sport: "rugby",

    competition: match.competition,
    matchId: match.id,
    match: `${match.home} vs ${match.away}`,
    home: match.home,
    away: match.away,
    homeId: match.homeId ?? null,
    awayId: match.awayId ?? null,
    homeLogo: match.homeLogo || null,
    awayLogo: match.awayLogo || null,
    date: match.date,

    market,
    line,
    bookmaker: "",
    odds,

    probability,
    impliedProbability: value.impliedProbability,
    value: value.value,
    edge: value.edge,
    decision: value.decision,

    predictedHomePoints: Number(match.predictedHomePoints || 0),
    predictedAwayPoints: Number(match.predictedAwayPoints || 0),
    predictedTotalPoints: predictedTotal,

    modelEdgePoints,
    modelEdgePercent,

    sigma,
    confidence,
    recommendedTrend: match.recommendedTrend || null,

    scoreValue,
    finalDecision,

    placed: false,
    stake: 0,
    status: "draft",
    notes
  };

  /*
   * Mémorisation temporaire jusqu’au clic sur :
   * "Sauvegarder l’analyse" ou "Sauvegarder le pari".
   */
  pendingFrenchFlairAnalyses.set(
    String(match.id),
    analysis
  );

  const box = document.getElementById(
    `ff-calculation-${match.id}`
  );

  if (!box) {
    alert("Zone de résultat introuvable.");
    return;
  }

  const decisionClass =
    finalDecision === "VALUE"
      ? "badge-value"
      : "badge-no";

  box.innerHTML = `
    <hr/>

    <p>
      Marché analysé :
      <strong>${market} ${line.toFixed(1)}</strong>
    </p>

    <p>
      Cote :
      <strong>${odds.toFixed(2)}</strong>
    </p>

    <hr/>

    <p>
      Total prédit SportLab :
      <strong>${predictedTotal.toFixed(1)} pts</strong>
    </p>

    <p>
      Ligne bookmaker :
      ${line.toFixed(1)} pts
    </p>

    <p>
      Écart modèle / bookmaker :
      <strong>
        ${modelEdgePoints >= 0 ? "+" : ""}
        ${modelEdgePoints.toFixed(1)} pts
      </strong>
    </p>

    <p>
      Écart relatif :
      <strong>
        ${modelEdgePercent >= 0 ? "+" : ""}
        ${modelEdgePercent.toFixed(1)}%
      </strong>
    </p>

    <hr/>

    <p>
      Probabilité SportLab :
      ${probabilityPercent.toFixed(1)}%
    </p>

    <p>
      Probabilité implicite :
      ${(value.impliedProbability * 100).toFixed(1)}%
    </p>

    <p>
      Value mathématique :
      ${(value.value * 100).toFixed(1)}%
    </p>

    <p>
      Edge :
      ${(value.edge * 100).toFixed(1)}%
    </p>

    <span class="badge ${decisionClass}">
      ${finalDecision} — ${scoreValue}%
      | Confiance ${confidence}%
    </span>

    <p class="small">
      Tu peux modifier la ligne ou la cote et recalculer avant de sauvegarder.
    </p>

    <button onclick="saveFrenchFlairAnalysis('${match.id}')">
      💾 Sauvegarder l’analyse
    </button>

    ${
      finalDecision === "VALUE"
        ? `
          <hr/>

          <label>
            <input
              type="checkbox"
              id="ff-placed-${match.id}"
            >
            Pari placé
          </label>

          <label>
            Montant misé
            <input
              id="ff-stake-${match.id}"
              type="number"
              min="0"
              step="0.01"
              placeholder="Ex : 10"
            >
          </label>

          <button onclick="saveFrenchFlairBet('${match.id}')">
            Sauvegarder le pari
          </button>
        `
        : ""
    }
  `;
};

/**
 * FRENCHFLAIR */
window.saveFrenchFlairAnalysis = function(matchId) {
  const pending = pendingFrenchFlairAnalyses.get(String(matchId));

  if (!pending) {
    alert("Calcule d’abord la value avant de sauvegarder.");
    return;
  }

  const match = getFrenchFlairMatchById(matchId);
  if (!match || !isMatchEditableBeforeKickoff(match)) {
    alert("Le match a commencé : l’analyse ne peut plus être modifiée.");
    return;
  }

  saveAnalysis(pending);
  saveFrenchFlairMatchWorkflow(matchId, {
    status: pending.finalDecision === "VALUE" ? "value" : "decided",
    decision: pending.finalDecision,
    event: { type: pending.finalDecision === "VALUE" ? "value" : "decided", label: pending.finalDecision === "VALUE" ? "VALUE détectée" : "Analyse enregistrée", note: `${pending.market} ${Number(pending.line).toFixed(1)} · cote ${Number(pending.odds).toFixed(2)}` }
  });
  pendingFrenchFlairAnalyses.delete(String(matchId));

  alert("Analyse sauvegardée dans le Journal.");

  // VALUE ou NO VALUE : le match disparaît seulement
  // après ton action volontaire de sauvegarde.
  init();
};
window.saveFrenchFlairBet = function(matchId, analysisId) {
  const match = getFrenchFlairMatchById(matchId);
  console.log("[FrenchFlair] Objet match :", match);
  const analysis =
  pendingFrenchFlairAnalyses.get(String(matchId)) ||
  getAnalysisForMatch(match?.id);

  if (!match || !analysis) {
    alert("Analyse introuvable.");
    return;
  }

  if (!isMatchEditableBeforeKickoff(match)) {
    alert("Le match a commencé : aucun pari ne peut plus être ajouté ou modifié.");
    return;
  }

  const placed = document.getElementById(`ff-placed-${match.id}`)?.checked;
  const stake = Number(document.getElementById(`ff-stake-${match.id}`)?.value || 0);

  if (placed && stake <= 0) {
    alert("Saisis un montant misé valide.");
    return;
  }

  saveAnalysis({
  ...analysis,
  placed,
  stake,
  status: placed ? "betPlaced" : "completed"
});

pendingFrenchFlairAnalyses.delete(String(matchId));

if (!match?.id || !match?.date) {
  console.error(
    "[FrenchFlair] Match incomplet au moment de sauvegarder le pari :",
    match
  );

  alert(
    "Impossible d’enregistrer ce pari : identifiant ou date du match manquant."
  );

  return;
}

  const savedBet = createBet({
  source: "FrenchFlair",
  sport: "rugby",
  competition: match.competition || null,

  matchId: match.id ?? null,
  matchDate: match.date || null,

  match: `${match.home} vs ${match.away}`,
  home: match.home,
  away: match.away,
  homeId: match.homeId ?? null,
  awayId: match.awayId ?? null,
  homeLogo: match.homeLogo || null,
  awayLogo: match.awayLogo || null,
  market: `${analysis.market} ${analysis.line}`,
  line: analysis.line,
  odds: analysis.odds,
  probability: analysis.probability,
  value: analysis.value,
  edge: analysis.edge,
  decision: analysis.decision,
  placed,
  stake
});

  saveFrenchFlairMatchWorkflow(matchId, {
    status: placed ? "tracked" : (analysis.finalDecision === "VALUE" ? "value" : "decided"),
    placed: Boolean(placed), stake,
    event: { type: placed ? "tracked" : "decided", label: placed ? "Pari enregistré" : "Analyse enregistrée", note: placed ? `Mise : ${stake.toFixed(2)} €` : "Aucun pari placé" }
  });
  alert("Analyse FrenchFlair sauvegardée.");
  init();
};

function computeFrenchFlairProbability(match, market, line) {
  const mean = Number(match.predictedTotalPoints || 0);
  const sigma = Number(match.sigma || 0);

  if (!mean || !sigma || sigma <= 0 || !line) {
    return 0;
  }

  const z = (line - mean) / sigma;
  const overProbability = 1 - normalCdf(z);

  if (market === "OVER") {
    return clamp(overProbability, 0.01, 0.99);
  }

  return clamp(1 - overProbability, 0.01, 0.99);
}

function normalCdf(x) {
  return 0.5 * (1 + erf(x / Math.sqrt(2)));
}

function erf(x) {
  const sign = x >= 0 ? 1 : -1;
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const absX = Math.abs(x);
  const t = 1 / (1 + p * absX);

  const y =
    1 -
    (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) *
    t *
    Math.exp(-absX * absX);

  return sign * y;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function getFrenchFlairMatchById(matchId) {
  return frenchflairPayload?.matches?.find(
    match => String(match.id) === String(matchId)
  ) || null;
}
function computeFrenchFlairScore({ modelEdgePercent, confidence, sigma, predictedTotal, mathValue }) {
  const edgeScore = clamp(Math.max(modelEdgePercent, 0) / 10, 0, 1) * 40;
  const confidenceScore = clamp(confidence / 100, 0, 1) * 20;

  const sigmaRatio = predictedTotal > 0 ? sigma / predictedTotal : 1;
  const sigmaScore = clamp(1 - sigmaRatio, 0, 1) * 20;

  const mathValueScore = clamp(Math.max(mathValue, 0) / 0.10, 0, 1) * 20;

  return Math.round(edgeScore + confidenceScore + sigmaScore + mathValueScore);
}

function toggleSportLabMenu() {
  const header =
    document.querySelector(
      ".sportlab-app-header"
    );

  const toggle =
    document.getElementById(
      "sportlab-menu-toggle"
    );

  if (!header || !toggle) {
    return;
  }

  const isOpen =
    header.classList.toggle(
      "sportlab-menu-open"
    );

  toggle.setAttribute(
    "aria-expanded",
    String(isOpen)
  );

  toggle.setAttribute(
    "aria-label",
    isOpen
      ? "Fermer le menu"
      : "Ouvrir le menu"
  );

  document.body.classList.toggle(
    "sportlab-navigation-open",
    isOpen
  );
}

function closeSportLabMenu() {
  const header =
    document.querySelector(
      ".sportlab-app-header"
    );

  const toggle =
    document.getElementById(
      "sportlab-menu-toggle"
    );

  if (!header) {
    return;
  }

  header.classList.remove(
    "sportlab-menu-open"
  );

  document.body.classList.remove(
    "sportlab-navigation-open"
  );

  if (toggle) {
    toggle.setAttribute(
      "aria-expanded",
      "false"
    );

    toggle.setAttribute(
      "aria-label",
      "Ouvrir le menu"
    );
  }
}

window.refreshSportLab = async function() {
  currentPage = "home";
  await init();
};

window.navigateSportLab = function(page) {
  closeSportLabMenu();

  currentPage = page;
  init();
};

window.toggleSportLabMenu = toggleSportLabMenu;

window.closeSportLabMenu = closeSportLabMenu;

document.addEventListener(
  "click",
  async event => {
    const button = event.target.closest(
      "#run-settlement-diagnostic"
    );

    if (!button) {
      return;
    }

    button.disabled = true;
    button.textContent =
      "⏳ Diagnostic en cours...";

    try {
      await runSettlementDiagnostics();

      const appData =
        await loadApplicationData();

      drawhunterPayload =
        appData.drawhunterPayload;

      frenchflairPayload =
        appData.frenchflairPayload;

      renderApplication(
        document.getElementById("app"),
        {
          ...appData,
          currentPage
        }
      );

      initializeUi();
    } catch (error) {
      console.error(
        "[Diagnostics] Échec du diagnostic :",
        error
      );

      button.disabled = false;
      button.textContent =
        "🔄 Relancer le diagnostic";
    }
  }
);


export async function startLegacyApplication() {
  return init();
}

export function getLegacyRuntimeState() {
  return {
    currentPage,
    drawhunterLoaded: Boolean(drawhunterPayload),
    frenchflairLoaded: Boolean(frenchflairPayload)
  };
}


// SPORTLAB V7.1.2B — Commandes du Cloud Dashboard
window.runSportLabCloudSync = async function() {
  const button = document.querySelector(".cloud-dashboard-actions .sl-button-primary");
  if (button) { button.disabled = true; button.textContent = "Synchronisation…"; }
  try {
    await window.SportLabCore?.cloud?.syncNow?.({ reason: "manual" });
  } catch (error) {
    console.error("[Cloud Dashboard] Synchronisation impossible", error);
  } finally {
    await init();
  }
};

window.openSportLabCloudSettings = function() {
  document.getElementById("sportlab-cloud-button")?.click();
};

window.addEventListener("sportlab:cloud-config", () => {
  if (currentPage === "cloud") init();
});
window.addEventListener("online", () => { if (currentPage === "cloud") init(); });
window.addEventListener("offline", () => { if (currentPage === "cloud") init(); });

// SPORTLAB V7.1.2C — Recovery & Conflict Center
async function refreshRecoveryCenter() { await init(); }
window.previewSportLabRecovery = async function() {
  try { await window.SportLabCore?.recovery?.preview?.(); } catch (error) { alert(`Comparaison impossible : ${error.message}`); }
  await refreshRecoveryCenter();
};
window.restoreSportLabCloudToLocal = async function() {
  if (!confirm("Cette opération remplacera les données locales après création d’un snapshot de sécurité. Continuer ?")) return;
  try { await window.SportLabCore?.recovery?.restoreCloudToLocal?.(); } catch (error) { alert(`Restauration impossible : ${error.message}`); }
  await refreshRecoveryCenter();
};
window.forceSportLabLocalToCloud = async function() {
  if (!confirm("Cette opération sauvegardera volontairement la version locale dans le cloud. Continuer ?")) return;
  try { await window.SportLabCore?.recovery?.forceLocalToCloud?.(); } catch (error) { alert(`Sauvegarde impossible : ${error.message}`); }
  await refreshRecoveryCenter();
};
window.mergeSportLabCloudData = async function() {
  if (!confirm("Lancer la fusion intelligente Local / Cloud avec la stratégie LWW ?")) return;
  try { await window.SportLabCore?.recovery?.smartMerge?.(); } catch (error) { alert(`Fusion impossible : ${error.message}`); }
  await refreshRecoveryCenter();
};
window.restoreSportLabSnapshot = async function(snapshotId) {
  if (!confirm("Restaurer ce snapshot local ? Un snapshot de sécurité sera créé avant l’opération.")) return;
  try { window.SportLabCore?.recovery?.restoreSnapshot?.(snapshotId); } catch (error) { alert(`Rollback impossible : ${error.message}`); }
  await refreshRecoveryCenter();
};
window.addEventListener("sportlab:recovery-updated", () => { if (currentPage === "recovery" || currentPage === "cloud") init(); });
